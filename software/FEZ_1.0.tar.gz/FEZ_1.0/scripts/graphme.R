#!/usr/bin/env Rscript

library(knitr)
library(markdown)

knit("fez_graph.Rmd")
markdownToHTML("fez_graph.md","fez_graph.html",stylesheet="./custom.css")
