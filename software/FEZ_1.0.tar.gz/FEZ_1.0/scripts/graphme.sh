knitr::spin("fez_graph.R")
