#' FEZ Model Simulation Script
#'
# Load Libraries:
library(knitr)
options(scipen=999)
#' # Data Analysis for FEZ Simulation
#' 

a <- read.table("done.txt", sep="\t", nrow=4)
a <- data.matrix(a, rownames.force = NA)

extinctions <- read.table("extinction.txt",header=F)
Ncsv <- a[1,]
NspeciesInit=a[2,]
Nsnapshots=a[3,]
Extinctionscale=a[4,]

print(Ncsv)
print(NspeciesInit)
print(Nsnapshots)
print(Extinctionscale)

Extinctionscale=as.numeric(Extinctionscale)
Nsnapshots=as.numeric(Nsnapshots)
Nspecies=matrix(0,Ncsv+1,NspeciesInit) 

for(i in 0:Ncsv){
  thelength=length(table(as.matrix(read.csv(paste("tree_",i,".csv",sep=""), header=F))))
  Nspecies[i+1,1:thelength]=table(as.matrix(read.csv(paste("tree_",i,".csv",sep=""), header=F)))
} 
ext_xaxis = seq(from=0, to=Extinctionscale*(Nsnapshots-1),by=Extinctionscale)
plot(ext_xaxis,extinctions$V1,ylab="Number extinctions",xlab="Number of replacements", type = "b")

#plot species richness through time
Ncsv_xaxis = seq(from=0, to=Extinctionscale*(Nsnapshots-1),by=Extinctionscale*(Nsnapshots-1)/(Ncsv))
plot(Ncsv_xaxis, rowSums(Nspecies>0), xlab = "Number of replacements", ylab = "species richness", type = "b")

#plot rank abundance curves
par(mfrow = c(1,2))
par(oma = c(.5,.5,.5,.5))
for(i in 1:Ncsv){
  plot(1:NspeciesInit,sort(Nspecies[i,], decreasing = T), type = "b" ,xlim=c(1,NspeciesInit), ylim=c(0,max(Nspecies[i,])), xlab="Rank",ylab="Abundance",main="")
  plot(1:NspeciesInit,log(sort(Nspecies[i,], decreasing = T)), type = "b" ,xlim=c(1,NspeciesInit), ylim=c(0,max(log(Nspecies[i,]))), xlab="Rank",ylab="log(Abundance)",main="")
}
