/*************************************************
 * Author: Shane Barrantes, Taal Levi, Christopher M. Sullivan
 * Date: 3/27/2018
 * Title: functions.cpp
 *
 * This is the functions.cpp source code file
 * for the Forest Exclusion Zone Model
 * Simulation.
 * 
 * Copyright 2018
 * Department of Fish and Wildlife,
 * Center for Genome Research and Biocomputing
 * Oregon State University
 * Corvallis, OR 97331
 * Email: Taal.Levi@oregonstate.edu
*************************************************/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iomanip>
#include <fstream>
#include "functions.h"
#include <sstream>
#include <string.h>
#include <string>

using namespace std;

/**********************************************************************
 *** Function: buildTaggedTable
 *** Description: builds the table to see if a species has been tagged
 *** Parameters: numSp
 *** Pre-Conditions: none
 *** Post-Conditions: taggedTable
 **********************************************************************/
int* buildTaggedTable(int numSp){
	int* taggedTable = new int [numSp];
	for(int i = 0; i < numSp; i++){
		taggedTable[i] = 0;
	}
	return taggedTable;
}

/**********************************************************************
 *** Function:clearTaggedTable
 *** Description: returns all values in tagged table to 0 to signify that none are tagged
 *** Parameters: taggedTable, numSp
 *** Pre-Conditions: taggedTable must be made
 *** Post-Conditions: taggedTable
 **********************************************************************/
int* clearTaggedTable(int* taggedTable, int numSp){
	for(int i = 0; i < numSp; i++){
		taggedTable[i] = 0;
	}
	return taggedTable;
}

/**********************************************************************
 *** Function:addTaggedTable
 *** Description: flags a species as tagged so it won't be attempted again
 *** Parameters: taggedTable, species
 *** Pre-Conditions: taggedTable must be generated
 *** Post-Conditions: specified species is flagged as 1
 **********************************************************************/
int* addTaggedTable(int* taggedTable, int species){
	taggedTable[species] = 1;
	return taggedTable;
}

/**********************************************************************
 *** Function:printTaggedTable
 *** Description: prints the taggedTable to screen
 *** Parameters: taggedTable, numSp
 *** Pre-Conditions: taggedTable must be set
 *** Post-Conditions: none
 **********************************************************************/
void printTaggedTable(int* taggedTable, int numSp){
	for(int i = 0; i < numSp; i++){
		cout << "species " << i << " = " << taggedTable[i] << endl;
	}
}

/**********************************************************************
 *** Function: checkTaggedTable
 *** Description: check to see if a species is contained in the tagged Table
 *** Parameters: taggedTable, target
 *** Pre-Conditions: parameters must be set
 *** Post-Conditions: boolean 1 or 0
 **********************************************************************/
int checkTaggedTable(int* taggedTable, int target){
	int tmp;
	tmp = taggedTable[target];
	if(tmp == 0){
		return 0;
	} else{
		return 1;
	}
}

/**********************************************************************
 *** Function:buildLandscape
 *** Description: builds the landscape by placing a random species in every matrix cell
 *** Parameters: x, y, numSp
 *** Pre-Conditions: parameters must exist
 *** Post-Conditions: landscape is made
 **********************************************************************/
int** buildLandscape(int rows, int columns, int numSp){
	int** landscape;
	landscape = new int* [rows];
	for (int row = 0; row < rows; row++)
	{
		landscape[row] = new int[columns];
	}
	for(int i = 0; i < rows; i++ ){
		for(int j = 0; j < columns; j++){
			landscape[i][j] = -1;
		}
	}
	for(int i = 10; i < (rows - 10); i++ ){
		for(int j = 10; j < (columns - 10); j++){
			landscape[i][j] = rand() % numSp;
		}
	}
	return landscape;
}

/**********************************************************************
 *** Function:tallyTrees
 *** Description: tally how many of  each species are in the landscape
 *** Parameters: landscape, numSp, x, y
 *** Pre-Conditions: parameters must be set
 *** Post-Conditions: trees will be tallied correctly in tallyTable
 **********************************************************************/
int* tallyTrees(int** landscape, int numSp, int rows, int columns,
        int extraRows, int extracolumns){
	int* tallyTable;
	tallyTable = new int [numSp];
	for(int i = extraRows; i < rows - extraRows; i++ ){
		for(int j = extracolumns; j < columns - extracolumns; j++){
			tallyTable[landscape[i][j]]++;
		}
	}
	return tallyTable;
}

/**********************************************************************
 *** Function:getRow
 *** Description: gets a row value that's in bounds
 *** Parameters: rows
 *** Pre-Conditions: rows is set
 *** Post-Conditions: a single row will be returned
 **********************************************************************/
int getRow(int rows){
	int row = 0;
	while(row < 10 || row > rows - 11){
	   row = rand() % rows;
	}
	return row;
}

/**********************************************************************
 *** Function:getColumn
 *** Description: gets a column value that's in bounds
 *** Parameters: columns
 *** Pre-Conditions: columns is set
 *** Post-Conditions: a single column will be returned
 **********************************************************************/
int getColumn(int columns){
	int column = 0;
	while(column < 10 || column > columns - 11){
		column = rand() % columns;
	}
	return column;
}

/**********************************************************************
 *** Function: checkExclusionZone
 *** Description: Checks to see if the sample species exists inside the exclusion zone.
 *** Parameters: landscape, targetRandRow, targetRandCol, sampleRandRow, sampleRandCol, exclusion
 *** Pre-Conditions: parameters must have been set
 *** Post-Conditions: checkExlusion will return 1, 0, or error.
 **********************************************************************/
int checkExclusionZone(int** landscape, int targetRandRow, int targetRandCol,
  int sampleRandRow, int sampleRandCol, int exclusionZone){
	int i, j;
	if(exclusionZone == 0){
		return 0;											// no matches
	} else if(exclusionZone == 1){
		if(landscape[targetRandRow][targetRandCol] ==
			landscape[sampleRandRow][sampleRandCol]){
                	return 1; 										// any matches
		} else {
			return 0;										// no matches
		}
	} else if (exclusionZone == 9){
		for(i = (targetRandRow - 1); i <= (targetRandRow + 1); i++){
			for(j = (targetRandCol - 1); j <= (targetRandCol + 1); j++){
				if(landscape[sampleRandRow][sampleRandCol] == landscape[i][j]) return 1;	// any matches
			}
		}
		return 0;											// no matches
	} else if (exclusionZone == 25){
		for(i = (targetRandRow - 2); i <= (targetRandRow + 2); i++){
			for(j = (targetRandCol - 2); j <= (targetRandCol + 2); j++){
				if(landscape[sampleRandRow][sampleRandCol] == landscape[i][j]) return 1;	// any matches
			}
		}
		return 0;											// no matches
	} else {
		cerr << "Exclusion zone in checkExclusion is out of bounds." << endl;				// errpr
		exit(1);
	}
}
/**********************************************************************
 *** Function: tallyExtinctions
 *** Description: Counts how many species are extinct at the end of the simulation
 *** Parameters: speciesTableRows, numSp, extinctionsHolder, speciesTable
 *** Pre-Conditions: all parameters must be set and valid
 *** Post-Conditions: extinctonsHolder will contain all extinctions
 **********************************************************************/
 int* tallyExtinctions(int speciesTableRows, int numSp, int *extinctionsHolder, int** speciesTable){
   int extinctionCounter = 0;
   for(int i = 0; i < speciesTableRows; i++){
    extinctionCounter = 0;
     for(int c = 0; c < numSp; c++){
       if(speciesTable[i][c] == 0){
         extinctionCounter++;
       }
     }
     extinctionsHolder[i] = extinctionCounter;
   }
   return extinctionsHolder;
 }

/**********************************************************************
 *** Function: createCSV
 *** Description: generate a CSV of the landscape
 *** Parameters: landscape, totalRows, totalColumns, csvName
 *** Pre-Conditions: all parameters must be set
 *** Post-Conditions: a CSV of the inputted landscape will be generated
 **********************************************************************/
void createCSV(int** landscape, int totalRows, int totalColumns, char* csvName,
    int borderRows, int borderColumns){
	ofstream csvFile;
	csvFile.open(csvName);
	for(int i = borderRows; i < totalRows - borderRows; i++){
		for(int j = borderColumns; j < totalColumns - borderColumns; j++){
			csvFile << landscape[i][j];
			if(j != (totalColumns-borderColumns) - 1){
        			csvFile << ",";
			}
		}
		csvFile << "\n";
	}
	csvFile.close();
}

/**********************************************************************
 *** Function: createDoneFile
 *** Description: The done.txt file will be generated.
 *** Parameters: numCsv, numSp, numSnapshots, snapshotScale
 *** Pre-Conditions: parameters must be set
 *** Post-Conditions: The done.txt file will be created with correct values
 **********************************************************************/
 void createDoneFile(int numCsv, int numSp, int numSnapshots,
 	int snapshotScale){
	ofstream doneFile;
	doneFile.open("done.txt");
	doneFile << numCsv << endl;
	doneFile << numSp << endl;
	doneFile << (numSnapshots + 1) << endl;
	doneFile << snapshotScale << endl;
	doneFile.close();
 }

 /**********************************************************************
  *** Function: createExtinctionsFile
  *** Description: the extinctions file will be gnerated
  *** Parameters: extinctionsHolder, speciesTableRows
  *** Pre-Conditions: paramteres must be set
  *** Post-Conditions: the extinction.txt file will be made.
  **********************************************************************/
void createExtinctionsFile(int* extinctionsHolder, int speciesTableRows){
	ofstream extinctionsFile;
	extinctionsFile.open("extinction.txt");
	for(int i = 0; i < speciesTableRows; i++){
		extinctionsFile << extinctionsHolder[i] << endl;
	}
	extinctionsFile.close();
}

/**********************************************************************
 *** Function: initialValueHandler
 *** Description: check to see if the controller passed values are valid 
 *** Parameters: rows, columns, treeReplacements, numSp, exclusionZone,
 ***         forcedReplacement, numCsv, numSnapshots
 *** Pre-Conditions: Values have been passed by the controller
 *** Post-Conditions: Values passed are generally valid
 **********************************************************************/
void initialValueHandler(int rows, int columns, long long treeReplacements,
  int numSp, int exclusionZone, int forcedReplacement, int numCsv,
  int numSnapshots){
	if(rows < 30 || rows > 27000){
		cerr << "The value passed as rows in out of bounds.";
		exit(2);
	}
	if(columns < 30 || columns > 27000){
		cerr << "The value passed as columns in out of bounds.";
		exit(3);
	}
	if(treeReplacements < 1 || treeReplacements > 1000000000000){
		cerr << "The value passed as treeReplacements in out of bounds.";
		exit(4);
	}
	if(numSp < 1 || numSp > 30000){
		cerr << "The value passed as numSp is out of bounds.";
		exit(5);
	}
	if(exclusionZone == 0 || exclusionZone == 1 || exclusionZone == 9 ||
		exclusionZone == 25){
	} else {
		cerr << "The value passed as exclusion is out of bounds.";
		exit(6);
	}
	if(forcedReplacement < 0 || forcedReplacement > 100){
		cerr << "The value passed as forceReplacement is out of bounds.";
		exit(7);
	}
	if(numCsv < 0 || numCsv > 30000){
		cerr << "The value passed as numCsv is out of bounds.";
		exit(8);
	}
	if(numSnapshots > 30000 || numSnapshots < 0){
		cerr << "numSnapshots is out of bounds.";
		exit(9);
	}
}

/**********************************************************************
 *** Function: buildSpeciesTable
 *** Description: creates a matrix of snapshots by numsp to monitor species
 *** Parameters: speciesTableRows, numSp
 *** Pre-Conditions: parameters are set
 *** Post-Conditions: speciesTable is made with the correct dimensions
 **********************************************************************/
int** buildSpeciesTable(int speciesTableRows, int numSp){
	int** speciesTable;
	speciesTable = new int* [speciesTableRows];
	for (int row = 0; row < speciesTableRows; row++)
	{
		speciesTable[row] = new int[numSp];
	}
	for(int i = 0; i < speciesTableRows; i++ ){			//fix rows and columns. need to take into account the extra boundary made from the waterzone.
		for(int j = 0; j < numSp; j++){
			speciesTable[i][j] = 0;
		}
	}
	return speciesTable;
}
