/***************************************************************
 * Authors: Shane Barrantes, Taal Levi, Christopher M. Sullivan
 * Date: 3/27/2018
 * Title: main.cpp
 *
 * This is the main.cpp source code file
 * for the Forest Exclusion Zone Model
 * Simulation.
 *
 * Copyright 2018
 * Department of Fish and Wildlife,
 * Center for Genome Research and Biocomputing
 * Oregon State University
 * Corvallis, OR 97331
 * Email: Taal.Levi@oregonstate.edu
***************************************************************/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iomanip>
#include <fstream>
#include "functions.h"
#include <string>
#include <sstream>
#include <string.h>
#include <math.h>

using namespace std;

int main(int argc, char *argv[]){
	srand(time(NULL));
	if(argc < 9 || argc > 9){
		cerr << "Please enter the correct number of arguments." << endl;
		cerr << "This binary is not meant to be ran by itself," << endl;
		cerr << "instead run it via ../controller.py." << endl;
		exit(10);
	}
	int rows = atoi(argv[1]);
	int cols = atoi(argv[2]);
	long long treeReplacements = atoll(argv[3]);
	int numSp = atoi(argv[4]);
	int exclusionZone = atoi(argv[5]);
	int forcedReplacement = atoi(argv[6]);
	int numCsv = atoi(argv[7]);
	int numSnapshots = atoi(argv[8]);
	initialValueHandler(rows, cols, treeReplacements, numSp, exclusionZone, forcedReplacement, numCsv, numSnapshots);
	int borderRows = ((rows * .2) + 20) / 2;
	int borderCols = ((cols * .2) + 20) / 2;
	int totalRows = rows +(rows * .2) + 20;
	int totalCols = cols + (cols * .2) + 20;
	int snapshotScale = 0;
	int *extinctionsHolder;
	long long yearCount = 1;
	long csvs = treeReplacements / numCsv;
	if(numCsv > 0){
		csvs = treeReplacements / numCsv;
	}
	int targetRow, targetCol, sampleRow, sampleCol, sampleTarget, checkedTarget,
		r, c, tmp, checkEx;
	ofstream myfile, startfile, extinctions;
	int* taggedTable = buildTaggedTable(numSp);
	int csvCounter = 1;
	char csvName[20] = "tree_0.csv";
	char countHold[5];
	long long pastYear = 0;
	int speciesHolder = -1;
	int snapshotCounter = 0;
	int repeatYear = 0;
	bool newSampleFlag = false;
	int** landscape = buildLandscape(totalRows, totalCols, numSp);  
	int speciesTableRows = numSnapshots+1;
	int** speciesTable = buildSpeciesTable(speciesTableRows, numSp);

	createCSV(landscape, totalRows, totalCols, csvName, borderRows, borderCols);

	if(numSnapshots > 0){
		extinctionsHolder = new int[speciesTableRows];
		snapshotScale = floor(treeReplacements/numSnapshots);
		for(r = borderRows; r < (totalRows - borderRows); r++){
			for(c = borderCols; c < (totalCols - borderCols); c++){
				speciesHolder = landscape[r][c];
				speciesTable[snapshotCounter][speciesHolder]++;
			}
		}
		for(c = 0; c < numSp; c++){
			speciesTable[snapshotCounter + 1][c] = speciesTable[snapshotCounter][c];
		}
		snapshotCounter = 1;
	}

	for(long long t = 1; t <= treeReplacements; t++){
		if(numSnapshots > 0){
			if(t % snapshotScale == 0 && repeatYear <= 0){
				if(t != treeReplacements){
					for(c = 0; c < numSp; c++){
						speciesTable[snapshotCounter + 1][c] =
							speciesTable[snapshotCounter][c];
					}
					snapshotCounter++;
				}
			}
		}
		if(newSampleFlag == false){
			targetRow = getRow(totalRows);
			targetCol = getColumn(totalCols);
		}
		sampleRow = getRow(totalRows);
		sampleCol = getColumn(totalCols);
		sampleTarget = landscape[sampleRow][sampleCol];
		checkedTarget = checkTaggedTable(taggedTable, sampleTarget);
		if(checkedTarget == 1){
			t--;
			repeatYear++;
		}
		else{
			checkEx = checkExclusionZone(landscape, targetRow, targetCol, sampleRow, 
				sampleCol, exclusionZone);  
			if(checkEx == 1){
				tmp = 0;                              
				tmp = rand() % forcedReplacement;    
				if(tmp == 1){
					if(numSnapshots > 0){
            					if(targetRow < (totalRows - borderRows) && targetRow >= borderRows
              					&& targetCol < (totalCols - borderCols) &&
              					targetCol >= borderCols){
							speciesTable[snapshotCounter][landscape[targetRow][targetCol]]--;	
						}
					}
					landscape[targetRow][targetCol] = landscape[sampleRow][sampleCol];		
					if(numSnapshots > 0){
            					if(targetRow < (totalRows - borderRows) && targetRow >= borderRows
              					&& targetCol < (totalCols - borderCols) &&
              					targetCol >= borderCols){
							         speciesTable[snapshotCounter][landscape[targetRow][targetCol]]++;
						}
					}
					yearCount++;	 
					repeatYear = 0;
					clearTaggedTable(taggedTable, numSp);		
					newSampleFlag = false;
				} else {
					addTaggedTable(taggedTable,landscape[sampleRow][sampleCol]);
					t--;
					repeatYear++;
					newSampleFlag = true;
				}
			}
			if(checkEx == 0){                                                                
				if(numSnapshots > 0){
					if(targetRow < (totalRows - borderRows) && targetRow >= borderRows
					&& targetCol < (totalCols - borderCols) &&
					targetCol >= borderCols){
						speciesTable[snapshotCounter][landscape[targetRow][targetCol]]--;
					}
				}
				landscape[targetRow][targetCol] = landscape[sampleRow][sampleCol];
				if(numSnapshots > 0){
					if(targetRow < (totalRows - borderRows) && targetRow >= borderRows
					&& targetCol < (totalCols - borderCols) &&
					targetCol >= borderCols){
            					speciesTable[snapshotCounter][landscape[targetRow][targetCol]]++;	
					}
				}
				yearCount++;
				repeatYear = 0;
				clearTaggedTable(taggedTable, numSp);
				newSampleFlag = false;
			}
			if(yearCount % csvs == 0 && repeatYear <= 0){	
				strcpy(csvName, "tree_");
				sprintf(countHold, "%d", csvCounter);
				strcat(csvName, countHold);
				strcat(csvName, ".csv");
				if(pastYear != yearCount){
					createCSV(landscape, totalRows, totalCols, csvName, borderRows, borderCols);
					csvCounter++;
					cout << "yearCount: " << yearCount << endl;
				}
				pastYear = yearCount;
			}
		}
	}
	if(numSnapshots > 0){
		extinctionsHolder = tallyExtinctions(speciesTableRows, numSp, extinctionsHolder, speciesTable);
		createExtinctionsFile(extinctionsHolder, speciesTableRows);
		delete [] extinctionsHolder;
	}
	for(int del = 0; del < totalRows; del++){         
		delete [] landscape[del];
	} 
	for(int del = 0; del < speciesTableRows; del++){          
		delete [] speciesTable[del];
	}
	delete [] speciesTable;
	delete [] landscape;
	delete [] taggedTable;
	createDoneFile(numCsv, numSp, numSnapshots, snapshotScale);
}
