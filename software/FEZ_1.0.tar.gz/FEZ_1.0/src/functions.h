/*************************************************
 * Author: Shane Barrantes, Taal Levi, Christopher M. Sullivan
 * Date: 3/27/2018
 * Title: functions.h
 *
 * This is the functions.h source code file
 * for the Forest Exclusion Zone Model
 * Simulation.
 *
 * Copyright 2018
 * Department of Fish and Wildlife,
 * Center for Genome Research and Biocomputing
 * Oregon State University
 * Corvallis, OR 97331
 * Email: Taal.Levi@oregonstate.edu
 * *************************************************/

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iomanip>
#include <fstream>

void printTaggedTable(int*, int);
void createCSV(int**, int, int, char*, int, int);
void initialValueHandler(int, int, long long, int, int, int, int, int);
void createDoneFile(int, int, int, int);
void createExtinctionsFile(int*, int);
int checkTaggedTable(int*, int);
int getRow(int);               
int getColumn(int);                 
int checkExclusionZone(int**, int, int, int, int, int);
int* buildExclusionTable(int);
int* buildTaggedTable(int);
int* clearTaggedTable(int*, int);
int* addTaggedTable(int*, int);
int* tallyTrees(int**, int, int, int, int, int);
int* tallyExtinctions(int, int, int*, int**);
int** buildLandscape(int, int, int);
int** buildSpeciesTable(int, int);
int** initialSpeciesTable(int**, int**);
int** copyLandscape(int**, int, int);
int** readInCSV(int**, char*);
