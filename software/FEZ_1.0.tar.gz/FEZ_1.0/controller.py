#!/usr/bin/env python
import sys
import os
import shutil
import getopt
from subprocess import call
global program_path
program_path = ""
executable = program_path + "/bin/fez"
html_output = program_path + "/runs/html_output"

def treepic():
	print("***********************")
	print("  ______ ______ ______ ")
	print(" |  ____|  ____|___  / ")
	print(" | |__  | |__     / /  ")
	print(" |  __| |  __|   / /   ")
	print(" | |    | |____ / /__  ")
	print(" |_|    |______/_____| ")
 
def main(argv):
   global rows
   global cols
   global treeReplacements
   global numsp
   global exclusion
   global iterations
   global forceReplacements
   global numCsvs
   global numSnapshots
   rows = '0'
   cols = ''
   numsp = ''
   treeReplacements = ''
   exclusion = ''
   iterations = '1'
   forceReplacements = '20'
   numCsvs = '10'
   numSnapshots= ''
   
   try:
      opts, args = getopt.getopt(argv,"hx:y:t:n:e:f:c:i:p:l:s:",["rows=","cols=","treeReplacements=","numsp=","exclusion=","forceReplacements=","numCsvs=","iterations=","numSnapshots="])
   except getopt.GetoptError:
      print 'controller.py -x <rows> -y <cols> -t <treeReplacements> -n <numsp> -e <exclusion> -f <forceReplacements> -c <numCsvs> -i <iterations> -s <numSnapshots>'
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         print("")
         print ' controller.py -x <rows> -y <cols> -t <treeReplacements> -n <numsp> -e <exclusion> -f <forceReplacements> -c <numCsvs> -i <iterations> -s <numSnapshots>'
         print(" [Options Required]")
         print(" -x      The number of rows for the landscape")
         print(" -y      The number of cols for the landscape")
         print(" -t      The number of tree replacements the simulation will run for")
         print(" -n      The initial number of species placed on the landscape")
         print(" -e      The exclusion zone that each tree will have")
         print(" -f      The chance that a tree will replace even if there's a matching tree in the exclusion zone")
         print(" -c      The number of csv that will be generated")
         print(" -i      The number of simulations with these parameters that will run")
	 print(" -s	 The number of snapshots that will be taken")
         print("")
         print("   Example: controller.py -x 620 -y 620 -t 100 -n 300 -e 1 -f 20 -c 5 -i 1 -s 400000")
         print("")
         print("")
         print("")
         sys.exit()
      elif opt in ("-x", "--rows"):
         rows = arg
      elif opt in ("-y", "--cols"):
         cols = arg
      elif opt in ("-t", "--treeReplacements"):
         treeReplacements = arg
      elif opt in ("-n", "--numsp"):
         numsp = arg
      elif opt in ("-e", "--exclusion"):
         exclusion = arg
      elif opt in ("-f", "--forceReplacements"):
         forceReplacements = arg
      elif opt in ("-c", "--numCsvs"):
         numCsvs = arg
      elif opt in ("-i", "--iterations"):
         iterations = int(arg)
      elif opt in ("-s", "--numSnapshots"):
         numSnapshots = arg

if __name__ == "__main__":
    if len(sys.argv) < 2:
       print("No options have been supplied.")
       print("controller.py -x <rows> -y <cols> -t <treeReplacements> -n <numsp> -e <exclusion> -f <forceReplacements> -c <numCsvs> -i <iterations> -s <numSnapshots>")
       sys.exit(1)
    main(sys.argv[1:])
    treepic()
    print("")
    print '  Dimension rows is: ', rows
    print '  Dimension cols is: ', cols
    print '  Number of Tree Replacements is: ', treeReplacements
    print '  Number of Species is: ', numsp
    print '  Exclusion is: ', exclusion
    print '  ForceReplace is: ', forceReplacements
    print '  Number of Csvs is: ', numCsvs
    print '  Number of Iterations is: ', iterations
    print '  Snapshot Number is: ', numSnapshots
    print("")
    print("  Beginning the simulation: ")
    pid = str(os.getpid())
    working_directory= os.getcwd()
    for x in range (0, iterations):
        target_directory = "fez_"+rows+"_"+cols+"_"+treeReplacements+"_"+numsp+"_"+exclusion+"_"+forceReplacements+"_"+numCsvs+"_"+str(iterations)+"_"+numSnapshots+"."+str(pid)+str(x)+".output"
        iterations = int(iterations)
	if not os.path.exists(target_directory):
            os.makedirs(target_directory)
        else:
            print("The target directory file already exists: ")
        target_directory = os.path.join(working_directory, target_directory)
        print("  HTML output will bin in:\n " + target_directory + " and\n " + working_directory + "/html_output")
	os.chdir(target_directory)
	csv_directory = "csvs"
	if not os.path.exists(csv_directory):
            os.makedirs(csv_directory)
        else:
            print("The csv directory file already exists: ")
	print("  CSV output will bin in:\n " + target_directory + "/" + csv_directory)
	csv_directory = os.path.join(target_directory, csv_directory)
        shutil.copy(program_path + "/scripts" + "/graphme.R", csv_directory)
        shutil.copy(program_path + "/scripts" + "/graphme.sh", csv_directory)
        shutil.copy(program_path + "/scripts" + "/fez_graph.R", csv_directory)
	os.chdir(csv_directory)
	call([executable, rows, cols, treeReplacements, numsp, exclusion, forceReplacements, numCsvs, numSnapshots])
	if os.path.exists(csv_directory + "/done.txt"):
            call(["R", "CMD", "BATCH", csv_directory + "/graphme.sh"])                                       
	    call(["R", "CMD", "BATCH", csv_directory + "/graphme.R"])
	    html_name = "tree_abundance_"+rows+"_"+cols+"_"+treeReplacements+"_"+numsp+"_"+exclusion+"_"+forceReplacements+"_"+numCsvs+"_"+numSnapshots+"." + str(pid) + str(x) + ".html"
	    call(["mv","fez_graph.html",html_name])
	    call(["cp",csv_directory + "/" + html_name,target_directory])
	    call(["cp","/" + target_directory + "/" + html_name, html_output])                                     
        if os.path.exists(csv_directory + "/done.txt"):
           call(["/bin/rm",csv_directory + "/graphme.sh.Rout",csv_directory + "/graphme.R",csv_directory + "/fez_graph.md",csv_directory + "/fez_graph.R",csv_directory + "/graphme.sh", csv_directory + "/graphme.Rout" , csv_directory + "/.RData"])
        os.chdir(working_directory)                                                     # step back into the working directory

    print("");
    print("  The run has finished:\n  Please look in the output directory for results.")
    print("  HTML is named with the following scheme...")
    print("  tree_abundance_rows_cols_treeReplacements_numsp_exclusion_forceReplacements_numCsvs_numberOfSnapshots.pid.iteration.html")
    print("");
    print("***********************")
